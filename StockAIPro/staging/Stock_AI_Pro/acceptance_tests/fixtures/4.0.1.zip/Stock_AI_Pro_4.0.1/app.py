print("fixture")
